const { defineConfig, devices } = require('@playwright/test');
const config = require('./config/ConfigManager');

/**
 * Playwright Configuration
 * ----------------------------------------------------------------------------
 * Reads everything from ConfigManager (which itself reads /environments/.env.*),
 * so switching environments never requires touching this file - only
 * `cross-env ENV=qa` (see package.json scripts) or setting ENV before running.
 */
module.exports = defineConfig({
  testDir: './tests',
  timeout: config.get('timeouts.default'),
  expect: {
    timeout: config.get('timeouts.action'),
  },

  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: config.get('execution.retries'),
  workers: config.get('execution.workers'),

  reporter: [
    ['list'],
    ['html', { open: 'never', outputFolder: 'playwright-report' }],
    ['allure-playwright', { resultsDir: 'allure-results' }],
    ['json', { outputFile: 'test-results/results.json' }],
  ],

  globalSetup: require.resolve('./global-setup/global-setup.js'),
  globalTeardown: require.resolve('./global-teardown/global-teardown.js'),

  use: {
    baseURL: config.get('baseURL'),
    headless: config.get('browser.headless'),
    viewport: config.get('browser.viewport'),
    actionTimeout: config.get('timeouts.action'),
    navigationTimeout: config.get('timeouts.navigation'),
    trace: config.get('artifacts.trace'),
    video: config.get('artifacts.video'),
    screenshot: config.get('artifacts.screenshot'),
    ignoreHTTPSErrors: true,
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } },
    { name: 'edge', use: { ...devices['Desktop Edge'], channel: 'msedge' } },
  ],

  outputDir: 'test-results/',
});
