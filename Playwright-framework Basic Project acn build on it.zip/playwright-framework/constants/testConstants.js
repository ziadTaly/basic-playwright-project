/**
 * testConstants
 * ----------------------------------------------------------------------------
 * Single source of truth for magic strings used across the suite - tags,
 * roles, statuses. Import instead of retyping string literals so a rename
 * only ever happens in one place.
 */
module.exports = {
  TAGS: {
    SMOKE: '@smoke',
    REGRESSION: '@regression',
    SANITY: '@sanity',
    INTEGRATION: '@integration',
    E2E: '@e2e',
    API: '@api',
    UI: '@ui',
    CRITICAL: '@critical',
    RELEASE: '@release',
    NEGATIVE: '@negative',
    BOUNDARY: '@boundary',
  },

  ROLES: {
    ADMIN: 'admin',
    CUSTOMER: 'customer',
    TELLER: 'teller',
    MANAGER: 'manager',
    AUDITOR: 'auditor',
  },

  HTTP_STATUS: {
    OK: 200,
    CREATED: 201,
    NO_CONTENT: 204,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    CONFLICT: 409,
    SERVER_ERROR: 500,
  },

  ACCOUNT_TYPES: {
    CHECKING: 'CHECKING',
    SAVINGS: 'SAVINGS',
    CREDIT: 'CREDIT',
  },
};
