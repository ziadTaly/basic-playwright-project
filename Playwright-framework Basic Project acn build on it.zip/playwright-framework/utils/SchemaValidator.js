const Ajv = require('ajv');

const ajv = new Ajv({ allErrors: true, strict: false });

/**
 * SchemaValidator
 * ----------------------------------------------------------------------------
 * Validates API responses against JSON Schemas stored under /api/schemas.
 * Supports Swagger/OpenAPI-derived schemas dropped into that folder.
 */
class SchemaValidator {
  static validate(schema, data) {
    const validateFn = ajv.compile(schema);
    const valid = validateFn(data);
    return {
      valid,
      errors: valid ? [] : validateFn.errors,
    };
  }

  static assertValid(schema, data) {
    const { valid, errors } = SchemaValidator.validate(schema, data);
    if (!valid) {
      throw new Error(`Schema validation failed:\n${JSON.stringify(errors, null, 2)}`);
    }
  }
}

module.exports = SchemaValidator;
