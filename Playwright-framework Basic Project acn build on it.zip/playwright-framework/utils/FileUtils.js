const fs = require('fs-extra');
const path = require('path');

/**
 * FileUtils
 * ----------------------------------------------------------------------------
 * Centralized file/test-data reading utilities.
 *
 * JSON reading is fully implemented (zero extra dependencies needed).
 * Excel/CSV/PDF readers are provided as thin wrappers with a clear contract -
 * install the optional packages listed in each method's docstring to enable
 * them for a specific project without bloating the core framework's
 * dependency footprint for teams that only need JSON/UI/API testing.
 */
class FileUtils {
  static readJson(relativePath) {
    const fullPath = path.resolve(process.cwd(), relativePath);
    return fs.readJsonSync(fullPath);
  }

  static writeJson(relativePath, data) {
    const fullPath = path.resolve(process.cwd(), relativePath);
    fs.ensureFileSync(fullPath);
    fs.writeJsonSync(fullPath, data, { spaces: 2 });
  }

  /**
   * Reads a CSV file into an array of row-objects keyed by header.
   * Requires: npm install csv-parse
   */
  static readCsv(relativePath) {
    let parseSync;
    try {
      // eslint-disable-next-line global-require
      ({ parse: parseSync } = require('csv-parse/sync'));
    } catch {
      throw new Error('readCsv() requires the optional dependency "csv-parse". Install with: npm install csv-parse');
    }
    const fullPath = path.resolve(process.cwd(), relativePath);
    const content = fs.readFileSync(fullPath, 'utf-8');
    return parseSync(content, { columns: true, skip_empty_lines: true });
  }

  /**
   * Reads an Excel worksheet into an array of row-objects.
   * Requires: npm install xlsx
   */
  static readExcel(relativePath, sheetName) {
    let XLSX;
    try {
      // eslint-disable-next-line global-require
      XLSX = require('xlsx');
    } catch {
      throw new Error('readExcel() requires the optional dependency "xlsx". Install with: npm install xlsx');
    }
    const fullPath = path.resolve(process.cwd(), relativePath);
    const workbook = XLSX.readFile(fullPath);
    const sheet = workbook.Sheets[sheetName || workbook.SheetNames[0]];
    return XLSX.utils.sheet_to_json(sheet);
  }

  /**
   * Extracts raw text from a PDF file.
   * Requires: npm install pdf-parse
   */
  static async readPdfText(relativePath) {
    let pdfParse;
    try {
      // eslint-disable-next-line global-require
      pdfParse = require('pdf-parse');
    } catch {
      throw new Error('readPdfText() requires the optional dependency "pdf-parse". Install with: npm install pdf-parse');
    }
    const fullPath = path.resolve(process.cwd(), relativePath);
    const buffer = fs.readFileSync(fullPath);
    const result = await pdfParse(buffer);
    return result.text;
  }

  static ensureDir(dirPath) {
    fs.ensureDirSync(dirPath);
  }

  static cleanDir(dirPath) {
    fs.emptyDirSync(dirPath);
  }
}

module.exports = FileUtils;
