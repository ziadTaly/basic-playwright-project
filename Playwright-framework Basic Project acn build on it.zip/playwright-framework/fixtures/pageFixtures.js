const base = require('@playwright/test');
const LoginPage = require('../pages/banking/LoginPage');
const InventoryPage = require('../pages/banking/InventoryPage');
const UserApiService = require('../api/services/UserApiService');

/**
 * pageFixtures
 * ----------------------------------------------------------------------------
 * Extends Playwright's base `test` with pre-instantiated Page Objects and API
 * services. This is THE key maintainability lever from the spec:
 *
 *   "Adding a new page should require minimal code."
 *
 * To add a new page to every test in the suite, add one fixture entry below -
 * no test file needs to change, and no test needs to manually `new` a page
 * object. Import `test`/`expect` from this file instead of '@playwright/test'.
 */
const test = base.test.extend({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  inventoryPage: async ({ page }, use) => {
    await use(new InventoryPage(page));
  },

  // eslint-disable-next-line no-empty-pattern
  userApi: async ({}, use) => {
    await use(new UserApiService());
  },

  /** Convenience fixture: a page that's already authenticated via UI login. */
  authenticatedPage: async ({ page }, use) => {
    const loginPage = new LoginPage(page);
    await loginPage.open();
    await loginPage.login(process.env.DEFAULT_USERNAME || 'standard_user', process.env.DEFAULT_PASSWORD || 'secret_sauce');
    await use(page);
  },
});

const { expect } = base;

module.exports = { test, expect };
