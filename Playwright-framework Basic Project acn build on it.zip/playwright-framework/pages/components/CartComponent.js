const BaseComponent = require('../../core/BaseComponent');

/**
 * CartComponent
 * ----------------------------------------------------------------------------
 * Small reusable component (cart icon + badge count) that could appear on
 * multiple pages of the app. Scoped to its root locator via BaseComponent.
 */
class CartComponent extends BaseComponent {
  get badge() {
    return this.root.locator('.shopping_cart_badge');
  }

  async getItemCount() {
    if (!(await this.badge.isVisible())) return 0;
    return Number(await this.badge.textContent());
  }

  async open() {
    await this.actions.click(this.root);
  }
}

module.exports = CartComponent;
