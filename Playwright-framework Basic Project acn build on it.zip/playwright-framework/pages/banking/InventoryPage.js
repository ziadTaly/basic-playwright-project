const BasePage = require('../../core/BasePage');
const CartComponent = require('../components/CartComponent');

/**
 * InventoryPage
 * ----------------------------------------------------------------------------
 * Represents the post-login "dashboard" (product listing on saucedemo,
 * standing in for e.g. an accounts/dashboard landing page in a real banking
 * app). Demonstrates composing a BaseComponent (CartComponent) into a Page
 * Object - the recommended pattern for headers, nav bars, modals, tables.
 */
class InventoryPage extends BasePage {
  constructor(page) {
    super(page);
    this.cart = new CartComponent(page, this.el.byCss('.shopping_cart_link'));
  }

  get pageTitle() {
    return this.el.byCss('.title');
  }

  get inventoryItems() {
    return this.el.byCss('.inventory_item');
  }

  get sortDropdown() {
    return this.el.byCss('[data-test="product-sort-container"]');
  }

  async isLoaded() {
    await this.assert.toBeVisible(this.pageTitle, 'Inventory page title should be visible');
  }

  async getItemCount() {
    return this.inventoryItems.count();
  }

  async sortBy(label) {
    await this.actions.selectDropdown(this.sortDropdown, label);
  }

  async addFirstItemToCart() {
    const firstAddButton = this.inventoryItems.first().locator('button');
    await this.actions.click(firstAddButton);
  }
}

module.exports = InventoryPage;
