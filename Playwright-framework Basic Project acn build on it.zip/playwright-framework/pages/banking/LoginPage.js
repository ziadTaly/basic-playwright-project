const BasePage = require('../../core/BasePage');

/**
 * LoginPage
 * ----------------------------------------------------------------------------
 * Sample Page Object showing the intended shape of every page in /pages:
 *   - locators declared as getters (always re-queried fresh, avoids staleness)
 *   - thin, readable workflow methods that delegate to this.actions/this.assert
 *   - an isLoaded() implementation for fail-fast navigation checks
 *
 * Demonstrates against https://www.saucedemo.com (public demo app) so the
 * suite is runnable out of the box. Swap locators/URLs for your real
 * banking app; the pattern does not change.
 */
class LoginPage extends BasePage {
  get usernameInput() {
    return this.el.byId('user-name');
  }

  get passwordInput() {
    return this.el.byId('password');
  }

  get loginButton() {
    return this.el.byId('login-button');
  }

  get errorMessage() {
    return this.el.byCss('[data-test="error"]');
  }

  async isLoaded() {
    await this.assert.toBeVisible(this.loginButton, 'Login button should be visible on LoginPage');
  }

  async open() {
    await this.goto('/');
    await this.isLoaded();
    return this;
  }

  async login(username, password) {
    this.log.step(`Logging in as "${username}"`);
    await this.actions.fill(this.usernameInput, username);
    await this.actions.fill(this.passwordInput, password);
    await this.actions.click(this.loginButton);
  }

  async getErrorText() {
    await this.waits.waitUntilVisible(this.errorMessage);
    return this.errorMessage.textContent();
  }
}

module.exports = LoginPage;
