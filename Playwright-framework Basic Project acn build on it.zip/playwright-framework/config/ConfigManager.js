const path = require('path');
const fs = require('fs-extra');
const dotenv = require('dotenv');

/**
 * ConfigManager
 * ----------------------------------------------------------------------------
 * Central, single source of truth for all environment/runtime configuration.
 * Implemented as a Singleton so every module in the framework reads the exact
 * same resolved configuration for the life of the process.
 *
 * Resolution order (highest priority last, i.e. later overrides earlier):
 *   1. environments/.env.<ENV>            (checked into repo, non-secret defaults)
 *   2. environments/.env.<ENV>.local       (git-ignored, local overrides/secrets)
 *   3. process.env                         (CI/CD injected secrets always win)
 *
 * Adding a new environment therefore requires ONLY a new .env file -
 * no framework code changes (see "Maintainability" goals in the README).
 */
class ConfigManager {
  constructor() {
    if (ConfigManager._instance) {
      return ConfigManager._instance;
    }

    this.env = (process.env.ENV || 'dev').toLowerCase();
    this._loadEnvFiles();
    this._config = this._buildConfig();

    ConfigManager._instance = this;
  }

  _loadEnvFiles() {
    const envDir = path.resolve(__dirname, '../environments');
    const baseFile = path.join(envDir, `.env.${this.env}`);
    const localFile = path.join(envDir, `.env.${this.env}.local`);

    if (fs.existsSync(baseFile)) {
      dotenv.config({ path: baseFile });
    } else {
      // eslint-disable-next-line no-console
      console.warn(`[ConfigManager] No env file found for "${this.env}" at ${baseFile}. Falling back to process.env only.`);
    }

    if (fs.existsSync(localFile)) {
      dotenv.config({ path: localFile, override: true });
    }
  }

  _buildConfig() {
    const toBool = (val, fallback = false) => {
      if (val === undefined || val === '') return fallback;
      return String(val).toLowerCase() === 'true';
    };
    const toInt = (val, fallback) => {
      const n = parseInt(val, 10);
      return Number.isNaN(n) ? fallback : n;
    };

    return {
      env: this.env,
      isProd: this.env === 'prod',

      baseURL: process.env.BASE_URL,
      apiBaseURL: process.env.API_BASE_URL,

      credentials: {
        username: process.env.DEFAULT_USERNAME,
        password: process.env.DEFAULT_PASSWORD,
        apiToken: process.env.API_TOKEN || '',
      },

      browser: {
        name: process.env.BROWSER || 'chromium',
        headless: toBool(process.env.HEADLESS, true),
        viewport: {
          width: toInt(process.env.VIEWPORT_WIDTH, 1440),
          height: toInt(process.env.VIEWPORT_HEIGHT, 900),
        },
      },

      timeouts: {
        default: toInt(process.env.DEFAULT_TIMEOUT, 30000),
        navigation: toInt(process.env.NAVIGATION_TIMEOUT, 30000),
        action: toInt(process.env.ACTION_TIMEOUT, 15000),
      },

      execution: {
        retries: toInt(process.env.RETRY_COUNT, 1),
        workers: toInt(process.env.WORKERS, 4),
      },

      artifacts: {
        trace: process.env.TRACE || 'on-first-retry',
        video: process.env.VIDEO || 'retain-on-failure',
        screenshot: process.env.SCREENSHOT || 'only-on-failure',
      },

      database: {
        type: process.env.DB_TYPE || 'postgres',
        host: process.env.DB_HOST,
        port: toInt(process.env.DB_PORT, 5432),
        name: process.env.DB_NAME,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
      },

      logLevel: process.env.LOG_LEVEL || 'info',
    };
  }

  get(key) {
    // supports dotted path e.g. config.get('timeouts.default')
    return key.split('.').reduce((acc, part) => (acc ? acc[part] : undefined), this._config);
  }

  getAll() {
    return this._config;
  }

  /** Guard used by any test/utility that could mutate data, to protect PROD. */
  assertNotProd(actionDescription = 'this action') {
    if (this._config.isProd) {
      throw new Error(
        `[ConfigManager] Refusing to run "${actionDescription}" against PROD. ` +
          `PROD is read-only by design. Target DEV/QA/SIT/UAT/PREPROD instead.`
      );
    }
  }
}

// Export a single shared instance (true Singleton across the whole test run)
module.exports = new ConfigManager();
module.exports.ConfigManager = ConfigManager;
