const { Logger } = require('../logger/Logger');

const log = new Logger('GlobalTeardown');

/**
 * Global Teardown
 * ----------------------------------------------------------------------------
 * Runs ONCE after the entire test run. Use for:
 *   - Closing shared DB connections/pools.
 *   - Publishing summary notifications (Slack/Teams) via /plugins.
 *   - Cleaning up any environment-level test data created in global-setup.
 */
module.exports = async function globalTeardown() {
  log.info('Running global teardown...');
  // Example: await slackNotifier.postRunSummary(...);
  log.info('Global teardown complete.');
};
