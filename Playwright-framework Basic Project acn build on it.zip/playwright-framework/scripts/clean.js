const fs = require('fs-extra');
const path = require('path');

/**
 * Cleans all generated artifact directories. Run with `npm run clean`.
 * Safe to run anytime - never touches source code, only run artifacts.
 */
const DIRS_TO_CLEAN = [
  'test-results',
  'playwright-report',
  'allure-results',
  'allure-report',
  'screenshots',
  'videos',
  'traces',
  'downloads',
  'logger/logs',
];

DIRS_TO_CLEAN.forEach((dir) => {
  const fullPath = path.resolve(__dirname, '..', dir);
  fs.emptyDirSync(fullPath);
  // eslint-disable-next-line no-console
  console.log(`Cleaned: ${dir}`);
});

// eslint-disable-next-line no-console
console.log('\nAll artifact directories cleaned.');
