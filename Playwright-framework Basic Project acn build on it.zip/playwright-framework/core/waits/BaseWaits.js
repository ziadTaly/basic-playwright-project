const config = require('../../config/ConfigManager');
const logger = require('../../logger/Logger').Logger;

const log = new logger('BaseWaits');

/**
 * BaseWaits
 * ----------------------------------------------------------------------------
 * Centralizes every "intelligent wait" the framework uses. The rule is simple:
 *   NEVER `page.waitForTimeout(x)` inside a page object or test.
 * Every wait here is condition-based (visibility, state, network, custom
 * predicate) with a bounded timeout and a readable failure message.
 */
class BaseWaits {
  constructor(page) {
    this.page = page;
    this.timeout = config.get('timeouts.action');
  }

  async waitUntilVisible(locator, options = {}) {
    await locator.waitFor({ state: 'visible', timeout: options.timeout || this.timeout });
  }

  async waitUntilHidden(locator, options = {}) {
    await locator.waitFor({ state: 'hidden', timeout: options.timeout || this.timeout });
  }

  async waitUntilAttached(locator, options = {}) {
    await locator.waitFor({ state: 'attached', timeout: options.timeout || this.timeout });
  }

  async waitUntilEnabled(locator, options = {}) {
    const timeout = options.timeout || this.timeout;
    await this.page.waitForFunction(
      (el) => el && !el.disabled && el.getAttribute('aria-disabled') !== 'true',
      await locator.elementHandle(),
      { timeout }
    );
  }

  async waitForNetworkIdle(options = {}) {
    await this.page.waitForLoadState('networkidle', { timeout: options.timeout || config.get('timeouts.navigation') });
  }

  async waitForDomContentLoaded(options = {}) {
    await this.page.waitForLoadState('domcontentloaded', { timeout: options.timeout || config.get('timeouts.navigation') });
  }

  /** Waits for a specific API response matching a URL substring/regex before proceeding. */
  async waitForApiResponse(urlPattern, options = {}) {
    return this.page.waitForResponse(
      (response) =>
        (typeof urlPattern === 'string' ? response.url().includes(urlPattern) : urlPattern.test(response.url())) &&
        response.status() < (options.maxAcceptableStatus || 400),
      { timeout: options.timeout || this.timeout }
    );
  }

  /** Waits until a known loading spinner / skeleton loader disappears. */
  async waitForSpinnerToDisappear(spinnerLocator, options = {}) {
    try {
      await spinnerLocator.waitFor({ state: 'visible', timeout: 2000 });
    } catch {
      return; // spinner never appeared - nothing to wait for
    }
    await spinnerLocator.waitFor({ state: 'hidden', timeout: options.timeout || this.timeout });
  }

  /** Waits until an element's bounding box stops changing (animation/layout settle). */
  async waitUntilStable(locator, options = {}) {
    const timeout = options.timeout || this.timeout;
    const pollInterval = options.pollInterval || 100;
    const stableChecks = options.stableChecks || 3;

    const start = Date.now();
    let lastBox = null;
    let stableCount = 0;

    while (Date.now() - start < timeout) {
      const box = await locator.boundingBox();
      if (box && lastBox && box.x === lastBox.x && box.y === lastBox.y) {
        stableCount += 1;
        if (stableCount >= stableChecks) return;
      } else {
        stableCount = 0;
      }
      lastBox = box;
      // eslint-disable-next-line no-await-in-loop
      await this.page.waitForTimeout(pollInterval);
    }
    log.warn(`Element did not fully stabilize within ${timeout}ms - proceeding cautiously.`);
  }

  /** Generic retry helper: retries an async predicate/action until it succeeds or times out. */
  async retryUntil(actionFn, { timeout = this.timeout, interval = 250, description = 'condition' } = {}) {
    const start = Date.now();
    let lastError;
    while (Date.now() - start < timeout) {
      try {
        const result = await actionFn();
        if (result) return result;
      } catch (err) {
        lastError = err;
      }
      // eslint-disable-next-line no-await-in-loop
      await this.page.waitForTimeout(interval);
    }
    throw new Error(
      `Timed out waiting for "${description}" after ${timeout}ms. ${lastError ? `Last error: ${lastError.message}` : ''}`
    );
  }

  async waitForURL(urlOrPattern, options = {}) {
    await this.page.waitForURL(urlOrPattern, { timeout: options.timeout || config.get('timeouts.navigation') });
  }
}

module.exports = BaseWaits;
