const BaseActions = require('./actions/BaseActions');
const BaseAssertions = require('./assertions/BaseAssertions');
const BaseWaits = require('./waits/BaseWaits');
const BaseElements = require('./elements/BaseElements');
const { Logger } = require('../logger/Logger');

/**
 * BaseComponent
 * ----------------------------------------------------------------------------
 * Component Object Pattern: represents a reusable UI fragment that appears
 * across multiple pages (header, nav, data table, modal, toast, pagination,
 * calendar widget, etc). A component is scoped to a root Locator so all its
 * internal locators are relative to that root - this makes components
 * composable and reusable inside any Page Object.
 *
 *   class DataTable extends BaseComponent {
 *     constructor(page, rootLocator) { super(page, rootLocator); }
 *     row(index) { return this.root.locator('tbody tr').nth(index); }
 *   }
 *
 *   // inside a Page Object:
 *   this.accountsTable = new DataTable(this.page, this.page.locator('#accounts-table'));
 */
class BaseComponent {
  /**
   * @param {import('@playwright/test').Page} page
   * @param {import('@playwright/test').Locator} rootLocator - scope for this component
   */
  constructor(page, rootLocator) {
    if (!rootLocator) throw new Error(`${this.constructor.name} requires a root Locator to scope its elements.`);
    this.page = page;
    this.root = rootLocator;
    this.actions = new BaseActions(page);
    this.assert = new BaseAssertions(page);
    this.waits = new BaseWaits(page);
    this.el = new BaseElements(page);
    this.log = new Logger(this.constructor.name);
  }

  async isVisible() {
    return this.root.isVisible();
  }

  async waitUntilVisible() {
    await this.waits.waitUntilVisible(this.root);
  }
}

module.exports = BaseComponent;
