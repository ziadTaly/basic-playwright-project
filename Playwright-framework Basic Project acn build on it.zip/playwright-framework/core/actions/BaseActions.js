const BaseWaits = require('../waits/BaseWaits');
const { Logger } = require('../../logger/Logger');

const log = new Logger('BaseActions');

/**
 * BaseActions
 * ----------------------------------------------------------------------------
 * Every interaction a Page Object performs should go through this class
 * (never call locator.click() directly from a Page Object). This gives us a
 * single place to add auto-waiting, retries, logging and screenshots-on-fail
 * for every action across the entire framework.
 */
class BaseActions {
  constructor(page) {
    this.page = page;
    this.waits = new BaseWaits(page);
  }

  async _withRetry(actionName, locator, fn, retries = 2) {
    let lastError;
    for (let attempt = 1; attempt <= retries + 1; attempt += 1) {
      try {
        // eslint-disable-next-line no-await-in-loop
        await fn();
        log.debug(`${actionName} succeeded`, { attempt });
        return;
      } catch (err) {
        lastError = err;
        log.warn(`${actionName} failed on attempt ${attempt}/${retries + 1}: ${err.message}`);
        if (attempt <= retries) {
          // eslint-disable-next-line no-await-in-loop
          await this.page.waitForTimeout(300 * attempt); // small backoff, bounded and intentional (not a blind wait for state)
        }
      }
    }
    throw new Error(`Action "${actionName}" failed after ${retries + 1} attempts: ${lastError.message}`);
  }

  async click(locator, options = {}) {
    await this.waits.waitUntilVisible(locator);
    await this._withRetry('click', locator, () => locator.click(options));
  }

  /** "Safe click" - scrolls into view, waits for stability, then clicks. Use for flaky/animated elements. */
  async safeClick(locator, options = {}) {
    await this.waits.waitUntilVisible(locator);
    await locator.scrollIntoViewIfNeeded();
    await this.waits.waitUntilStable(locator);
    await this._withRetry('safeClick', locator, () => locator.click(options));
  }

  async retryClick(locator, options = {}) {
    await this._withRetry('retryClick', locator, () => locator.click(options), options.retries || 3);
  }

  async doubleClick(locator, options = {}) {
    await this.waits.waitUntilVisible(locator);
    await locator.dblclick(options);
  }

  async hover(locator) {
    await this.waits.waitUntilVisible(locator);
    await locator.hover();
  }

  async fill(locator, value, options = {}) {
    await this.waits.waitUntilVisible(locator);
    await locator.fill('');
    await locator.fill(String(value), options);
  }

  /** Types with a per-character delay - useful for fields with debounced validation/JS listeners. */
  async typeSlowly(locator, value, delay = 80) {
    await this.waits.waitUntilVisible(locator);
    await locator.click();
    await locator.pressSequentially(String(value), { delay });
  }

  async selectDropdown(locator, valueOrLabel) {
    await this.waits.waitUntilVisible(locator);
    try {
      await locator.selectOption({ label: valueOrLabel });
    } catch {
      await locator.selectOption(valueOrLabel);
    }
  }

  async uploadFile(locator, filePathOrPaths) {
    await locator.setInputFiles(filePathOrPaths);
  }

  async downloadFile(triggerLocator, downloadDir) {
    const [download] = await Promise.all([this.page.waitForEvent('download'), triggerLocator.click()]);
    const savePath = `${downloadDir}/${download.suggestedFilename()}`;
    await download.saveAs(savePath);
    return savePath;
  }

  async scrollIntoView(locator) {
    await locator.scrollIntoViewIfNeeded();
  }

  async dragAndDrop(sourceLocator, targetLocator) {
    await sourceLocator.dragTo(targetLocator);
  }

  async pressKey(key) {
    await this.page.keyboard.press(key);
  }

  async check(locator) {
    await this.waits.waitUntilVisible(locator);
    if (!(await locator.isChecked())) await locator.check();
  }

  async uncheck(locator) {
    await this.waits.waitUntilVisible(locator);
    if (await locator.isChecked()) await locator.uncheck();
  }

  async selectRadio(locator) {
    await this.waits.waitUntilVisible(locator);
    await locator.check();
  }

  /** Handles a native JS dialog (alert/confirm/prompt) for the next action triggered. */
  async handleDialog(action = 'accept', promptText) {
    this.page.once('dialog', async (dialog) => {
      if (action === 'accept') await dialog.accept(promptText);
      else await dialog.dismiss();
    });
  }

  async switchToNewTab(triggerLocator) {
    const [newPage] = await Promise.all([this.page.context().waitForEvent('page'), triggerLocator.click()]);
    await newPage.waitForLoadState();
    return newPage;
  }

  frame(nameOrLocatorSelector) {
    return this.page.frameLocator(nameOrLocatorSelector);
  }

  async search(inputLocator, query, submitLocator) {
    await this.fill(inputLocator, query);
    if (submitLocator) {
      await this.click(submitLocator);
    } else {
      await this.page.keyboard.press('Enter');
    }
  }
}

module.exports = BaseActions;
