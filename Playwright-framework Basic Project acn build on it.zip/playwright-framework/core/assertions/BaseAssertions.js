const { expect } = require('@playwright/test');

/**
 * BaseAssertions
 * ----------------------------------------------------------------------------
 * Centralizes every assertion used across Page Objects/tests so wording,
 * timeout defaults and failure screenshots stay consistent. Tests should call
 * `this.assert.textToBe(...)` rather than raw `expect(...)` directly - this
 * keeps assertions swappable/extensible (e.g. adding custom banking
 * assertions like `assert.currencyEquals`) without touching every test.
 *
 * Soft assertions: call `assert.soft` variants to collect failures without
 * stopping the test, then call `assert.assertAllSoft()` at the end of the step.
 */
class BaseAssertions {
  constructor(page) {
    this.page = page;
    this._softErrors = [];
  }

  // ---- Hard assertions (fail immediately) -----------------------------------

  async textToBe(locator, expected, message) {
    await expect(locator, message).toHaveText(expected);
  }

  async textToContain(locator, expected, message) {
    await expect(locator, message).toContainText(expected);
  }

  async urlToBe(expected, message) {
    await expect(this.page, message).toHaveURL(expected);
  }

  async titleToBe(expected, message) {
    await expect(this.page, message).toHaveTitle(expected);
  }

  async toBeVisible(locator, message) {
    await expect(locator, message).toBeVisible();
  }

  async toBeHidden(locator, message) {
    await expect(locator, message).toBeHidden();
  }

  async toBeEnabled(locator, message) {
    await expect(locator, message).toBeEnabled();
  }

  async toBeDisabled(locator, message) {
    await expect(locator, message).toBeDisabled();
  }

  async countToBe(locator, expected, message) {
    await expect(locator, message).toHaveCount(expected);
  }

  async valueToBe(locator, expected, message) {
    await expect(locator, message).toHaveValue(expected);
  }

  async screenshotToMatch(locatorOrPage, name, options = {}) {
    await expect(locatorOrPage).toHaveScreenshot(name, {
      maxDiffPixelRatio: options.threshold ?? 0.02,
      ...options,
    });
  }

  // ---- Soft assertions (collect, then assert together) ----------------------

  async soft(assertionFn, description) {
    try {
      await assertionFn();
    } catch (err) {
      this._softErrors.push(`${description || 'Soft assertion'}: ${err.message}`);
    }
  }

  assertAllSoft() {
    if (this._softErrors.length > 0) {
      const report = this._softErrors.map((e, i) => `  ${i + 1}. ${e}`).join('\n');
      const errors = [...this._softErrors];
      this._softErrors = [];
      throw new Error(`${errors.length} soft assertion(s) failed:\n${report}`);
    }
  }

  // ---- Domain-friendly custom assertions -------------------------------------

  /** Compares two currency/amount strings numerically, ignoring symbols/formatting. */
  async currencyEquals(locator, expectedAmount, message) {
    const raw = await locator.textContent();
    const numeric = parseFloat(String(raw).replace(/[^0-9.-]/g, ''));
    expect(numeric, message || `Expected currency value ${numeric} to equal ${expectedAmount}`).toBeCloseTo(
      parseFloat(expectedAmount),
      2
    );
  }
}

module.exports = BaseAssertions;
