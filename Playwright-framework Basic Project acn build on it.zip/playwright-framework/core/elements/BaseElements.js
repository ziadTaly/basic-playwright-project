/**
 * BaseElements
 * ----------------------------------------------------------------------------
 * Smart locator strategy. Priority order (most-resilient first):
 *   1. data-testid / data-test   (dedicated automation hooks - preferred)
 *   2. role + accessible name    (resilient, also validates accessibility)
 *   3. id / name
 *   4. text
 *   5. css
 *   6. xpath                     (last resort only - brittle & slow)
 *
 * Page Objects should prefer `this.el.byTestId(...)` / `this.el.smart(...)`
 * over hardcoding `page.locator('xpath=...')`.
 */
class BaseElements {
  constructor(page) {
    this.page = page;
  }

  byTestId(testId) {
    return this.page.locator(`[data-testid="${testId}"], [data-test="${testId}"]`);
  }

  byId(id) {
    return this.page.locator(`#${id}`);
  }

  byName(name) {
    return this.page.locator(`[name="${name}"]`);
  }

  byRole(role, options = {}) {
    return this.page.getByRole(role, options);
  }

  byText(text, options = {}) {
    return this.page.getByText(text, options);
  }

  byLabel(label, options = {}) {
    return this.page.getByLabel(label, options);
  }

  byPlaceholder(placeholder) {
    return this.page.getByPlaceholder(placeholder);
  }

  byCss(selector) {
    return this.page.locator(selector);
  }

  /** Last resort only - prefer any of the strategies above. */
  byXPath(xpath) {
    return this.page.locator(`xpath=${xpath}`);
  }

  /**
   * "Smart" resolver: accepts a descriptor object and tries strategies in
   * resilience order, returning the first that matches at least one element
   * in the DOM. Useful for self-healing style page objects:
   *
   *   await this.el.smart({ testId: 'submit-btn', role: 'button', text: 'Submit' }).click();
   */
  smart({ testId, role, roleOptions, id, name, text, label, placeholder, css, xpath } = {}) {
    const candidates = [];
    if (testId) candidates.push(() => this.byTestId(testId));
    if (role) candidates.push(() => this.byRole(role, roleOptions));
    if (id) candidates.push(() => this.byId(id));
    if (name) candidates.push(() => this.byName(name));
    if (label) candidates.push(() => this.byLabel(label));
    if (placeholder) candidates.push(() => this.byPlaceholder(placeholder));
    if (text) candidates.push(() => this.byText(text));
    if (css) candidates.push(() => this.byCss(css));
    if (xpath) candidates.push(() => this.byXPath(xpath));

    if (candidates.length === 0) {
      throw new Error('BaseElements.smart() requires at least one locator strategy to be provided.');
    }

    // Returns a Playwright Locator chain using .or() so Playwright itself
    // resolves whichever strategy matches first/is actionable - this is the
    // "self-healing" mechanism: if a testId disappears after a UI change,
    // the same call transparently falls back to role/text/css.
    return candidates.slice(1).reduce((acc, fn) => acc.or(fn()), candidates[0]());
  }
}

module.exports = BaseElements;
