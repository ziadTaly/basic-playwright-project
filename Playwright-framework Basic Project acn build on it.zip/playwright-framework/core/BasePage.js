const BaseActions = require('./actions/BaseActions');
const BaseAssertions = require('./assertions/BaseAssertions');
const BaseWaits = require('./waits/BaseWaits');
const BaseElements = require('./elements/BaseElements');
const config = require('../config/ConfigManager');
const { Logger } = require('../logger/Logger');

/**
 * BasePage
 * ----------------------------------------------------------------------------
 * Every Page Object in /pages MUST extend this class. It wires up:
 *   - this.actions    (BaseActions)    click/fill/upload/etc.
 *   - this.assert      (BaseAssertions) centralized assertions
 *   - this.waits       (BaseWaits)      intelligent waiting
 *   - this.el          (BaseElements)   smart locator resolution
 *   - this.log         (scoped Logger)
 *
 * This is the composition root that keeps individual Page Objects thin -
 * a new Page Object only needs to declare its locators and page-specific
 * workflows; all cross-cutting behavior is inherited.
 */
class BasePage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    if (!page) throw new Error(`${this.constructor.name} requires a Playwright "page" instance.`);
    this.page = page;
    this.actions = new BaseActions(page);
    this.assert = new BaseAssertions(page);
    this.waits = new BaseWaits(page);
    this.el = new BaseElements(page);
    this.log = new Logger(this.constructor.name);
    this.baseURL = config.get('baseURL');
  }

  /** Navigates to a path relative to baseURL (or an absolute URL) and waits for load. */
  async goto(pathOrUrl = '/') {
    const url = /^https?:\/\//i.test(pathOrUrl) ? pathOrUrl : `${this.baseURL}${pathOrUrl}`;
    this.log.step(`Navigating to ${url}`);
    await this.page.goto(url, { waitUntil: 'domcontentloaded' });
    return this;
  }

  async getTitle() {
    return this.page.title();
  }

  async getCurrentUrl() {
    return this.page.url();
  }

  async reload() {
    await this.page.reload({ waitUntil: 'domcontentloaded' });
  }

  /** Takes a manually-triggered screenshot (auto screenshots-on-failure are configured globally). */
  async takeScreenshot(name) {
    const filePath = `screenshots/${name}-${Date.now()}.png`;
    await this.page.screenshot({ path: filePath, fullPage: true });
    return filePath;
  }

  /**
   * Hook for subclasses: override to assert the page's defining element(s)
   * are present, and call it right after navigation for a fail-fast pattern.
   *   class LoginPage extends BasePage {
   *     async isLoaded() { await this.assert.toBeVisible(this.loginButton); }
   *   }
   */
  async isLoaded() {
    throw new Error(`${this.constructor.name} must implement isLoaded().`);
  }
}

module.exports = BasePage;
