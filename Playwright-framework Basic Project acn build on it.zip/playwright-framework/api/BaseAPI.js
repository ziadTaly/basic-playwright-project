const axios = require('axios');
const config = require('../config/ConfigManager');
const { Logger } = require('../logger/Logger');

/**
 * BaseAPI
 * ----------------------------------------------------------------------------
 * Foundation for the API layer (Service/Repository pattern). Every API
 * "service" class (e.g. UserApiService, AccountApiService) extends this and
 * gets a pre-configured axios client with:
 *   - Base URL from ConfigManager (per-environment)
 *   - Bearer / Basic auth helpers
 *   - Request/response logging (method, url, status, duration)
 *   - Consistent error shape
 *
 * This is the "Repository Pattern for API" layer referenced in the spec:
 * tests never call axios directly, they call a Service method
 * (e.g. `userService.createUser(payload)`), which is the single place that
 * knows the endpoint, headers and response shape.
 */
class BaseAPI {
  constructor(baseURL = config.get('apiBaseURL')) {
    this.log = new Logger(this.constructor.name);
    this.client = axios.create({
      baseURL,
      timeout: config.get('timeouts.action'),
      validateStatus: () => true, // let tests/assertions decide on status codes, don't throw here
    });

    this.client.interceptors.request.use((request) => {
      request.metadata = { start: Date.now() };
      this.log.debug(`→ ${request.method.toUpperCase()} ${request.url}`);
      return request;
    });

    this.client.interceptors.response.use((response) => {
      const duration = Date.now() - response.config.metadata.start;
      this.log.info(`← ${response.status} ${response.config.method.toUpperCase()} ${response.config.url} (${duration}ms)`);
      return response;
    });
  }

  setBearerToken(token) {
    this.client.defaults.headers.common.Authorization = `Bearer ${token}`;
  }

  setBasicAuth(username, password) {
    this.client.defaults.auth = { username, password };
  }

  setHeader(key, value) {
    this.client.defaults.headers.common[key] = value;
  }

  async get(url, config2 = {}) {
    return this.client.get(url, config2);
  }

  async post(url, data, config2 = {}) {
    return this.client.post(url, data, config2);
  }

  async put(url, data, config2 = {}) {
    return this.client.put(url, data, config2);
  }

  async patch(url, data, config2 = {}) {
    return this.client.patch(url, data, config2);
  }

  async delete(url, config2 = {}) {
    return this.client.delete(url, config2);
  }

  async uploadFile(url, fieldName, fileBuffer, fileName) {
    const FormData = require('form-data'); // eslint-disable-line global-require
    const form = new FormData();
    form.append(fieldName, fileBuffer, fileName);
    return this.client.post(url, form, { headers: form.getHeaders() });
  }
}

module.exports = BaseAPI;
