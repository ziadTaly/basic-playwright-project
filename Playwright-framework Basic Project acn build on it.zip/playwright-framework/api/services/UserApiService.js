const BaseAPI = require('../BaseAPI');

/**
 * UserApiService
 * ----------------------------------------------------------------------------
 * Sample Service/Repository class demonstrating the pattern every API domain
 * (accounts, transactions, cards, payments...) should follow: one class per
 * resource, one method per operation, tests never touch axios directly.
 *
 * Backed by https://dummyjson.com (free, no-auth public mock REST API) purely
 * so this sample is runnable out of the box. Point `baseURL` at your real
 * service via API_BASE_URL in the environment file for actual banking
 * endpoints. Note: dummyjson simulates writes (POST/PUT/DELETE) - it echoes
 * back a realistic response but does not persist changes server-side.
 */
class UserApiService extends BaseAPI {
  async listUsers({ limit, skip } = {}) {
    return this.get('/users', { params: { limit, skip } });
  }

  async getUser(id) {
    return this.get(`/users/${id}`);
  }

  async createUser(payload) {
    return this.post('/users/add', payload);
  }

  async updateUser(id, payload) {
    return this.put(`/users/${id}`, payload);
  }

  async deleteUser(id) {
    return this.delete(`/users/${id}`);
  }

  async login(username, password) {
    return this.post('/auth/login', { username, password });
  }
}

module.exports = UserApiService;
