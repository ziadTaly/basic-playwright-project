const fs = require('fs-extra');
const path = require('path');

const LEVELS = { error: 0, warn: 1, info: 2, step: 2, debug: 3 };

const COLORS = {
  error: '\x1b[31m', // red
  warn: '\x1b[33m', // yellow
  info: '\x1b[36m', // cyan
  step: '\x1b[35m', // magenta
  debug: '\x1b[90m', // gray
  reset: '\x1b[0m',
};

/**
 * Logger
 * ----------------------------------------------------------------------------
 * Lightweight, dependency-free structured logger.
 * - Colorized console output for local debugging.
 * - Persists a plain-text log file per run under /logger/logs for CI artifacts.
 * - Supports scoped child loggers (e.g. logger.child('LoginPage')) so every
 *   line is traceable back to the module/page/step that produced it.
 */
class Logger {
  constructor(scope = 'Framework', level = process.env.LOG_LEVEL || 'info') {
    this.scope = scope;
    this.level = level in LEVELS ? level : 'info';
    this.logDir = path.resolve(__dirname, 'logs');
    fs.ensureDirSync(this.logDir);
    this.logFile = path.join(this.logDir, `run-${Logger._runId}.log`);
  }

  static get _runId() {
    if (!Logger.__runId) {
      Logger.__runId = new Date().toISOString().replace(/[:.]/g, '-');
    }
    return Logger.__runId;
  }

  child(scope) {
    return new Logger(`${this.scope}:${scope}`, this.level);
  }

  _write(level, message, meta) {
    if (LEVELS[level] > LEVELS[this.level]) return;

    const timestamp = new Date().toISOString();
    const metaStr = meta ? ` ${JSON.stringify(meta)}` : '';
    const line = `[${timestamp}] [${level.toUpperCase()}] [${this.scope}] ${message}${metaStr}`;

    const color = COLORS[level] || '';
    // eslint-disable-next-line no-console
    console.log(`${color}${line}${COLORS.reset}`);

    fs.appendFileSync(this.logFile, `${line}\n`);
  }

  info(message, meta) {
    this._write('info', message, meta);
  }

  warn(message, meta) {
    this._write('warn', message, meta);
  }

  error(message, meta) {
    this._write('error', message, meta);
  }

  debug(message, meta) {
    this._write('debug', message, meta);
  }

  /** Logs a human-readable test step, useful for step-by-step execution logs / reports. */
  step(stepName, meta) {
    this._write('step', `STEP → ${stepName}`, meta);
  }

  /** Wraps an async action, logging start/duration/failure automatically. */
  async time(label, asyncFn) {
    const start = Date.now();
    this.debug(`${label} - started`);
    try {
      const result = await asyncFn();
      this.debug(`${label} - completed in ${Date.now() - start}ms`);
      return result;
    } catch (err) {
      this.error(`${label} - failed after ${Date.now() - start}ms`, { error: err.message });
      throw err;
    }
  }
}

module.exports = new Logger('Framework');
module.exports.Logger = Logger;
