const fs = require('fs-extra');
const path = require('path');
const config = require('../config/ConfigManager');
const { Logger } = require('../logger/Logger');

const log = new Logger('GlobalSetup');

/**
 * Global Setup
 * ----------------------------------------------------------------------------
 * Runs ONCE before the entire test run (configured in playwright.config.js).
 * Responsibilities:
 *   - Ensure artifact directories exist (screenshots/videos/traces/allure).
 *   - Prime a reusable authenticated storage state (Session Reuse) so
 *     individual tests don't each pay the cost of a UI login.
 *   - Fail fast with a clear message if PROD is accidentally targeted for
 *     anything beyond read-only smoke checks.
 */
module.exports = async function globalSetup() {
  log.info(`Starting global setup for environment: ${config.get('env')}`);

  ['screenshots', 'videos', 'traces', 'allure-results', 'downloads', 'logger/logs'].forEach((dir) => {
    fs.ensureDirSync(path.resolve(__dirname, '..', dir));
  });

  if (config.get('isProd')) {
    log.warn('Running against PROD - only read-only smoke checks should be executed here.');
  }

  // Example of Session Reuse / Storage State priming:
  // Uncomment and adapt once real credentials/login flow are available.
  //
  // const { chromium } = require('@playwright/test');
  // const LoginPage = require('../pages/banking/LoginPage');
  // const browser = await chromium.launch();
  // const page = await browser.newPage();
  // const loginPage = new LoginPage(page);
  // await loginPage.open();
  // await loginPage.login(config.get('credentials.username'), config.get('credentials.password'));
  // await page.context().storageState({ path: 'environments/storageState.json' });
  // await browser.close();

  log.info('Global setup complete.');
};
