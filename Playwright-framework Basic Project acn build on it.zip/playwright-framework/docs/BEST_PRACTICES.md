# Best Practices

- **Never** use `page.waitForTimeout(x)` in a Page Object or test — every wait
  in this framework is condition-based (`BaseWaits`). If you hit a genuinely
  new waiting need, add a method to `BaseWaits`, don't inline a sleep.
- **Never** call Playwright locator methods directly from a test — go through
  `this.actions.*` / `this.assert.*` on a Page Object, so retries/logging stay
  centralized and consistent.
- **One Page Object per page/screen**, **one Component per reusable widget**.
  If a Page Object exceeds ~200–300 lines, it's usually a sign a component
  should be extracted.
- **Locator priority**: `data-testid` > role/label > id/name > text > css >
  xpath (last resort). Use `this.el.smart({...})` when you want automatic
  fallback across strategies.
- **Tag every test** (`@smoke`, `@regression`, `@sanity`, `@api`, `@negative`,
  `@boundary`, `@critical`) so CI/local runs can filter meaningfully.
- **Keep tests independent** — no test should depend on another test's
  side effects. Use fixtures (`authenticatedPage`) instead of chaining state.
- **Assertions belong to the test, not the Page Object** — Page Objects
  expose state/actions; the test file decides what "correct" looks like via
  `this.assert.*` / `expect(...)`.
- **Never target PROD with mutating actions.** Use `config.assertNotProd()` in
  any new helper that writes data.
- **Small, focused API Service classes** — one per resource/domain, mirroring
  how a backend team would split controllers.
- **Data must be disposable** — prefer `data/factories` (Faker-generated) over
  hardcoded fixtures where the test doesn't care about a _specific_ value.
- **Run `npm run lint` and `npm run format` before opening a PR.**
