# Extension Points — What's Real vs. What's a Contract to Wire Up

Being transparent about scope so nobody mistakes a documented hook for a
shipped integration.

## Fully implemented, runnable today

- Page Object Model + Component Object Pattern (`core/BasePage.js`, `core/BaseComponent.js`)
- Base action/assertion/wait/locator classes with real retry & auto-wait logic (no fixed timeouts)
- Config Singleton + 6 environments (dev/qa/sit/uat/preprod/prod), config-only to extend
- API layer (Service/Repository pattern) with real HTTP calls, logging, schema validation (ajv)
- Faker-based data Factory + Builder
- Allure + Playwright HTML + JSON reporting, wired into `playwright.config.js`
- Structured logger (console + file, scoped child loggers, step logging)
- Sample UI suite (4 tests) and API suite (5 tests) that pass against public demo targets
- ESLint + Prettier, `.gitignore`, GitHub Actions CI workflow
- `DatabaseClient` façade with a genuine Postgres/MySQL connection path (optional deps)

## Documented contracts — install the optional dependency and implement one method

These are **not faked**; they're a clean interface with a clear "add this one
piece" instruction, so a project team wires in exactly what it needs instead
of carrying dependencies (and false confidence) it doesn't:

| Capability                      | Where                                                       | What to add                                                                                                                     |
| ------------------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| Oracle / SQL Server             | `database/DatabaseClient.js`                                | one `case` block + `npm install oracledb` / `mssql`                                                                             |
| Excel / CSV / PDF test data     | `utils/FileUtils.js`                                        | `npm install xlsx` / `csv-parse` / `pdf-parse` (methods already call them correctly, just optional so core install stays light) |
| Slack/Teams/Email notifications | `plugins/`                                                  | drop in a new plugin file following `SlackNotifierPlugin.js`, call from `global-teardown`                                       |
| Visual regression               | `core/assertions/BaseAssertions.js` → `screenshotToMatch()` | already uses Playwright's built-in `toHaveScreenshot` — add baselines per project                                               |
| Accessibility checks            | new `core/AccessibilityChecker.js`                          | `npm install @axe-core/playwright`, run `AxeBuilder` against a page, assert zero violations                                     |

## Explicitly NOT included (would be theater, not tooling)

The original spec also asked for things that require a live AI backend, paid
third-party accounts, or a running Jira/Figma/SharePoint instance to mean
anything real:

- **AI test/page/locator generation from BRDs, Figma, Swagger, user stories** —
  this requires calling an LLM with real project documents; there's no
  generic way to "build" this without your actual documents and an API key.
  The clean way to add it: a `scripts/ai-generate.js` that reads a file,
  calls the Anthropic API (see your organization's existing Claude API key),
  and writes a draft spec file into `tests/generated/` for a human to review
  before it's trusted — never auto-committed, never run unreviewed in CI.
- **MCP integration with Jira/Figma/Confluence/SharePoint/etc.** — each needs
  a real account, real credentials, and a running MCP server for that
  product. Framework-side, this is just another Node script calling an MCP
  client; there's nothing to "pre-build" without a target system to point at.
- **AI self-healing that rewrites source code automatically** — intentionally
  NOT built as "automatic," per the spec's own instruction ("never update
  source code automatically without approval"). What IS built:
  `BaseElements.smart()` already gives you _runtime_ self-healing (tries
  testId → role → id → text → css, whichever matches), which covers the
  actual reliability benefit without the risk of unreviewed code mutation.
- **Security/penetration test suites (XSS/SQLi/CSRF fuzzing)** — real
  security testing needs a licensed scanner (Burp, OWASP ZAP) or a
  security team's sign-off to run safely against a real banking app; a
  placeholder fuzzer would give false assurance.
- **Live execution dashboard** — Allure already provides trend/history/pass-rate
  views out of the box (`npm run allure:generate`); a bespoke dashboard is a
  separate small web app project, not a test-framework file.

If any of the above becomes a real near-term need, the fastest path is: tell
me which one, and whether you have the target system/credentials/library
already available — then I can build the real, working integration rather
than a stub.
