# How to Add a New UI Test

1. Create a spec file under `tests/ui/<feature>.spec.js`.
2. Import `test`/`expect` from `fixtures/pageFixtures.js`, **not** `@playwright/test` directly - this is what gives you pre-wired page objects.
3. Tag every test with at least one suite tag: `@smoke`, `@regression`, `@sanity`, `@e2e`, plus optional `@negative` / `@boundary` / `@critical`.

```javascript
const { test, expect } = require('../../fixtures/pageFixtures');

test.describe('Account Statements', () => {
  test('customer can download a PDF statement @regression', async ({ authenticatedPage }) => {
    // authenticatedPage fixture already logged in via UI - build a page object around it
    // ...
  });
});
```

## Running your test

```bash
npx playwright test tests/ui/account-statements.spec.js
npx playwright test --grep @smoke
npx playwright test --headed --debug
```

## Conventions

- One `test.describe` per feature/page.
- Test titles are full sentences describing user-observable behavior ("customer can ..." / "system rejects ...").
- Never `page.waitForTimeout(x)` — use a `this.waits.*` method or add a new one to `BaseWaits` if a genuinely new wait condition is needed.
- Prefer `this.actions.*` over calling `locator.click()`/`locator.fill()` directly, so retries/logging stay consistent.
