# Contributing Guide

## Before you start

1. `npm install`
2. `npx playwright install --with-deps`
3. `npm test` — confirm the sample suite passes on your machine before making changes.

## Workflow

1. Create a branch: `feature/<short-description>` or `fix/<short-description>`.
2. Follow `docs/NAMING_CONVENTIONS.md` and `docs/BEST_PRACTICES.md`.
3. Add/extend tests for any new Page Object, Component, or API Service.
4. Run before opening a PR:
   ```bash
   npm run lint
   npm run format
   npm test
   ```
5. Open a PR describing:
   - What changed and why
   - Which environment(s) you validated against
   - Screenshots/Allure link for UI changes (optional but encouraged)

## Adding a new capability (not just a test)

- **New base behavior** (a new kind of wait/action/assertion) → add it to the
  relevant `core/*` base class so every Page Object gets it for free. Don't
  duplicate logic inside an individual Page Object.
- **New integration** (DB engine, notification channel, reporting tool) →
  follow the extension-point pattern described in `docs/EXTENSION_POINTS.md`:
  isolate it behind one method/one file, keep the dependency optional if not
  every project needs it.
- **New AI/MCP capability** → treat generated output as a _draft for human
  review_ (write to `tests/generated/` or similar), never auto-commit or
  auto-run in CI without a human approving the diff first.

## Code review checklist (for reviewers)

- [ ] No `page.waitForTimeout()` introduced
- [ ] No direct `locator.click()`/`.fill()` in a test (goes through `actions`)
- [ ] New Page Object implements `isLoaded()`
- [ ] New test is tagged (`@smoke`/`@regression`/etc.)
- [ ] No secrets committed in `.env.*` files
- [ ] No mutating action possible against `ENV=prod` without `assertNotProd()`
