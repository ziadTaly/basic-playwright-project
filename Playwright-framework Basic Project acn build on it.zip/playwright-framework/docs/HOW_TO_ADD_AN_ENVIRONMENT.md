# How to Add a New Environment

No framework code changes are required — configuration only.

1. Copy an existing file: `cp environments/.env.qa environments/.env.staging`
2. Update the values inside (`BASE_URL`, `API_BASE_URL`, credentials, DB settings, timeouts).
3. Run tests against it:

```bash
cross-env ENV=staging npx playwright test
```

Or add a convenience script to `package.json`:

```json
"test:staging": "cross-env ENV=staging playwright test"
```

## Secrets

Never commit real secrets into `.env.<name>` files that are checked into git.
For CI, inject secrets as real environment variables (they always take
precedence — see `ConfigManager._loadEnvFiles()` resolution order) or use a
git-ignored `.env.<name>.local` file for local-only secret overrides.

## PROD

`environments/.env.prod` is intentionally treated as read-only:
`ConfigManager.assertNotProd()` throws if any mutating helper
(`DatabaseClient.execute`, etc.) is called while `ENV=prod`. Only smoke/health
checks should target PROD.
