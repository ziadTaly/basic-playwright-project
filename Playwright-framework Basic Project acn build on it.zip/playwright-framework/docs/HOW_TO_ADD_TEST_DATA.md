# How to Add Test Data

## Static JSON data

Add a file under `data/json/<name>.json` and require it directly:

```javascript
const users = require('../../data/json/users.json');
```

## Dynamic/generated data (Factory + Builder)

Add a factory under `data/factories/<Domain>Factory.js` following
`UserFactory.js`'s pattern (`create`, `createMany`, plus a `Builder` class for
fine-grained overrides). Backed by `@faker-js/faker` — never hardcode PII-like
values in source.

## CSV / Excel / PDF-sourced data

Use `utils/FileUtils.js` (`readCsv`, `readExcel`, `readPdfText`). These call
optional dependencies (`csv-parse`, `xlsx`, `pdf-parse`) — install whichever
your project needs; the framework doesn't force every project to carry all
three.

## Environment-specific data

Anything that differs by environment (an existing test account ID, a fixed
reference number) belongs in `environments/.env.<name>` and is read via
`config.get(...)`, not hardcoded in a spec file.
