# How to Add API Tests

1. **Create a Service class** under `api/services/<Resource>ApiService.js` extending `BaseAPI`:

```javascript
const BaseAPI = require('../BaseAPI');

class AccountApiService extends BaseAPI {
  async getAccount(id) {
    return this.get(`/accounts/${id}`);
  }
  async createAccount(payload) {
    return this.post('/accounts', payload);
  }
  async closeAccount(id) {
    return this.delete(`/accounts/${id}`);
  }
}

module.exports = AccountApiService;
```

2. **(Optional) Add a JSON Schema** under `api/schemas/account.schema.json` for contract validation - can be generated from a Swagger/OpenAPI definition.

3. **Register a fixture** in `fixtures/pageFixtures.js`:

```javascript
accountApi: async ({}, use) => { await use(new AccountApiService()); },
```

4. **Write the test** under `tests/api/`:

```javascript
const { test, expect } = require('../../fixtures/pageFixtures');
const SchemaValidator = require('../../utils/SchemaValidator');
const accountSchema = require('../../api/schemas/account.schema.json');

test('GET /accounts/:id returns a schema-valid account @api @smoke', async ({ accountApi }) => {
  const response = await accountApi.getAccount(101);
  expect(response.status).toBe(200);
  SchemaValidator.assertValid(accountSchema, response.data);
});
```

## Authentication for API tests

```javascript
const api = new AccountApiService();
api.setBearerToken(process.env.API_TOKEN);
// or
api.setBasicAuth(username, password);
```

## Guardrails

- Never call `execute()`/mutating endpoints against `ENV=prod` — `ConfigManager.assertNotProd()` is available to guard any helper that writes data.
- Keep one Service class per resource/domain — don't let one class grow to cover the whole API surface.
