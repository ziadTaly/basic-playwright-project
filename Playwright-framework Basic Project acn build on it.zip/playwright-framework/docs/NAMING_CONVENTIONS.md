# Naming Conventions

| Item                   | Convention                                | Example                                |
| ---------------------- | ----------------------------------------- | -------------------------------------- |
| Page Object file/class | PascalCase, suffix `Page`                 | `TransferFundsPage.js`                 |
| Component file/class   | PascalCase, suffix `Component`            | `CartComponent.js`                     |
| API Service file/class | PascalCase, suffix `ApiService`           | `AccountApiService.js`                 |
| Base classes           | PascalCase, prefix `Base`                 | `BaseActions.js`                       |
| Factory classes        | PascalCase, suffix `Factory`              | `UserFactory.js`                       |
| Builder classes        | PascalCase, suffix `Builder`              | `UserBuilder.js`                       |
| Test spec files        | kebab-case, suffix `.spec.js`             | `login.spec.js`, `users.api.spec.js`   |
| Test titles            | Full sentence, user-observable behavior   | `'valid user can log in successfully'` |
| Tags                   | lowercase, `@`-prefixed                   | `@smoke`, `@regression`, `@negative`   |
| Env files              | `.env.<environment>` lowercase            | `.env.qa`, `.env.preprod`              |
| Locator getters        | camelCase, noun describing the element    | `submitButton`, `errorMessage`         |
| Constants              | UPPER_SNAKE_CASE, grouped in `constants/` | `HTTP_STATUS.NOT_FOUND`                |
