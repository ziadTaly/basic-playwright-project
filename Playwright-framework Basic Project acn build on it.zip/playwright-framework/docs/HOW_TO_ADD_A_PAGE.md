# How to Add a New Page

1. **Create the file** under `pages/<domain>/YourPage.js`:

```javascript
const BasePage = require('../../core/BasePage');

class TransferFundsPage extends BasePage {
  get fromAccountDropdown() {
    return this.el.byTestId('from-account');
  }
  get toAccountDropdown() {
    return this.el.byTestId('to-account');
  }
  get amountInput() {
    return this.el.byTestId('amount');
  }
  get submitButton() {
    return this.el.byRole('button', { name: 'Transfer' });
  }
  get confirmationBanner() {
    return this.el.byTestId('transfer-success');
  }

  async isLoaded() {
    await this.assert.toBeVisible(this.submitButton, 'Transfer button should be visible');
  }

  async transfer({ from, to, amount }) {
    this.log.step(`Transferring ${amount} from ${from} to ${to}`);
    await this.actions.selectDropdown(this.fromAccountDropdown, from);
    await this.actions.selectDropdown(this.toAccountDropdown, to);
    await this.actions.fill(this.amountInput, amount);
    await this.actions.click(this.submitButton);
    await this.waits.waitUntilVisible(this.confirmationBanner);
  }
}

module.exports = TransferFundsPage;
```

2. **Register a fixture** in `fixtures/pageFixtures.js` (one line):

```javascript
const TransferFundsPage = require('../pages/banking/TransferFundsPage');
// ...
transferFundsPage: async ({ page }, use) => { await use(new TransferFundsPage(page)); },
```

3. **Use it in a test:**

```javascript
const { test, expect } = require('../../fixtures/pageFixtures');

test('customer can transfer funds between accounts @regression', async ({ transferFundsPage }) => {
  await transferFundsPage.transfer({ from: 'Checking', to: 'Savings', amount: '100.00' });
  await expect(transferFundsPage.confirmationBanner).toBeVisible();
});
```

That's it — no other framework file changes. If the page contains a
repeated widget (a table, a nav bar), extract it as a `BaseComponent` (see
`pages/components/CartComponent.js`) and compose it into the page's
constructor.
