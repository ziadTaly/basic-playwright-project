# Architecture

## Layered Architecture Diagram

```mermaid
graph TD
    A[Tests: tests/ui, tests/api] --> B[Fixtures: fixtures/pageFixtures.js]
    B --> C[Page Objects: pages/**]
    B --> D[API Services: api/services/**]
    C --> E[Components: pages/components/**]
    C --> F[Core: BasePage]
    D --> G[Core: BaseAPI]
    F --> H[BaseActions]
    F --> I[BaseAssertions]
    F --> J[BaseWaits]
    F --> K[BaseElements]
    E --> F
    F --> L[ConfigManager Singleton]
    G --> L
    F --> M[Logger]
    G --> M
    L --> N[environments/.env.*]
    A --> O[data/factories, data/json]
    A --> P[database/DatabaseClient]
    Q[global-setup] --> A
    A --> R[global-teardown]
    R --> S[plugins/*]
```

## Dependency Diagram

```mermaid
graph LR
    playwright.config.js --> ConfigManager
    playwright.config.js --> globalSetup
    playwright.config.js --> globalTeardown
    ConfigManager --> dotenv
    BaseAPI --> axios
    UserFactory --> faker
    SchemaValidator --> ajv
    DatabaseClient -.optional.-> pg
    DatabaseClient -.optional.-> mysql2
    FileUtils -.optional.-> xlsx
    FileUtils -.optional.-> csv-parse
    FileUtils -.optional.-> pdf-parse
```

## Test Execution Flow

```mermaid
sequenceDiagram
    participant CI as CI/CD Runner
    participant PW as Playwright Runner
    participant GS as global-setup
    participant T as Test (spec)
    participant FX as Fixture (Page/API)
    participant Core as Base Classes
    participant App as Application Under Test
    participant Rep as Reporters

    CI->>PW: npx playwright test
    PW->>GS: run once
    GS->>GS: ensure dirs, prime auth state
    PW->>T: execute test
    T->>FX: request loginPage / userApi fixture
    FX->>Core: instantiate Page/API with page/axios client
    T->>Core: call workflow method (e.g. login())
    Core->>App: perform action / API call
    App-->>Core: DOM state / HTTP response
    Core-->>T: resolved locator / response data
    T->>Rep: assertions pass/fail recorded
    PW->>Rep: generate HTML + Allure + JSON reports
```

## Why this structure supports 5–10 year maintainability

- **Adding a page** = one new file + one fixture line (see `HOW_TO_ADD_A_PAGE.md`). No existing file is modified (Open/Closed Principle).
- **Adding an environment** = one new `.env` file. Zero code changes.
- **Adding a project/domain** (e.g. "Corporate Portal" alongside "Banking") = a new subfolder under `pages/<domain>` and `tests/<domain>`, reusing every base class untouched.
- **Swapping a database engine** = implement one `case` in `DatabaseClient.connect()`; nothing else in the framework references the driver directly.
- **Swapping reporting/notification tools** = add a file under `plugins/`; core files never need to know it exists.

## Docker (notes)

A minimal `Dockerfile` for CI runners:

```dockerfile
FROM mcr.microsoft.com/playwright:v1.48.0-jammy
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
CMD ["npx", "playwright", "test"]
```

Build/run:

```bash
docker build -t fintech-pw-framework .
docker run --rm -e ENV=qa fintech-pw-framework
```
