const { test, expect } = require('../../fixtures/pageFixtures');
const SchemaValidator = require('../../utils/SchemaValidator');
const userSchema = require('../../api/schemas/user.schema.json');
const { UserFactory } = require('../../data/factories/UserFactory');

/**
 * Backed by https://dummyjson.com - a free, no-auth public mock API.
 * Writes (POST/PUT/DELETE) are simulated: dummyjson echoes back a realistic
 * response but does not persist the change server-side, which is exactly
 * the behavior a Service-layer/schema-validation test needs to demonstrate
 * the pattern without depending on a stateful backend.
 */
test.describe('Users API @api', () => {
  test('GET /users/:id returns a valid user matching schema @smoke @regression', async ({ userApi }) => {
    const response = await userApi.getUser(2);

    expect(response.status).toBe(200);
    SchemaValidator.assertValid(userSchema, response.data);
  });

  test('GET /users/:id for a non-existent user returns 404 @regression @negative', async ({ userApi }) => {
    const response = await userApi.getUser(999999);
    expect(response.status).toBe(404);
  });

  test('POST /users/add creates a user with generated data @regression', async ({ userApi }) => {
    const payload = UserFactory.create();
    const response = await userApi.createUser({ firstName: payload.firstName, lastName: payload.lastName, age: 30 });

    expect([200, 201]).toContain(response.status);
    expect(response.data).toHaveProperty('id');
    expect(response.data.firstName).toBe(payload.firstName);
  });

  test('PUT /users/:id updates a user @regression', async ({ userApi }) => {
    const response = await userApi.updateUser(2, { lastName: 'UpdatedByQA' });
    expect(response.status).toBe(200);
    expect(response.data.lastName).toBe('UpdatedByQA');
  });

  test('DELETE /users/:id removes a user @regression', async ({ userApi }) => {
    const response = await userApi.deleteUser(2);
    expect(response.status).toBe(200);
    expect(response.data).toHaveProperty('isDeleted', true);
  });
});
