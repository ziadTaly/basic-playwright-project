const { test, expect } = require('../../fixtures/pageFixtures');
const InventoryPage = require('../../pages/banking/InventoryPage');

test.describe('Inventory / Dashboard', () => {
  test('authenticated user can sort products and add to cart @regression', async ({ authenticatedPage }) => {
    const inventoryPage = new InventoryPage(authenticatedPage);
    await inventoryPage.isLoaded();

    await inventoryPage.sortBy('Price (low to high)');
    await inventoryPage.addFirstItemToCart();

    expect(await inventoryPage.cart.getItemCount()).toBe(1);
  });
});
