const { test, expect } = require('../../fixtures/pageFixtures');
const users = require('../../data/json/users.json');

/**
 * Login Suite
 * Tags: @smoke @regression - use `npm run test:smoke` / `--grep @smoke` to filter.
 */
test.describe('Login', () => {
  test('valid user can log in successfully @smoke @regression', async ({ loginPage, inventoryPage }) => {
    await loginPage.open();
    await loginPage.login(users.validUser.username, users.validUser.password);

    await inventoryPage.isLoaded();
    await expect(inventoryPage.page).toHaveURL(/inventory.html/);
    expect(await inventoryPage.getItemCount()).toBeGreaterThan(0);
  });

  test('locked out user sees an error message @regression', async ({ loginPage }) => {
    await loginPage.open();
    await loginPage.login(users.lockedOutUser.username, users.lockedOutUser.password);

    const errorText = await loginPage.getErrorText();
    expect(errorText).toContain('locked out');
  });

  test('invalid credentials are rejected @regression @negative', async ({ loginPage }) => {
    await loginPage.open();
    await loginPage.login(users.invalidUser.username, users.invalidUser.password);

    const errorText = await loginPage.getErrorText();
    expect(errorText).toContain('do not match');
  });

  test('username is required @regression @negative @boundary', async ({ loginPage }) => {
    await loginPage.open();
    await loginPage.login('', users.validUser.password);

    const errorText = await loginPage.getErrorText();
    expect(errorText).toContain('Username is required');
  });
});
