const axios = require('axios');
const { Logger } = require('../logger/Logger');

const log = new Logger('SlackNotifierPlugin');

/**
 * SlackNotifierPlugin
 * ----------------------------------------------------------------------------
 * Example of the Plugin Architecture: a self-contained module that hooks into
 * global-teardown (or a CI step) WITHOUT requiring any change to core
 * framework files. Add new plugins (Teams, Email, Jira, TestRail, Xray,
 * BrowserStack, Sauce Labs...) the same way: one file in /plugins exposing a
 * small, focused interface; wire it up where needed (global-teardown, CI
 * script) via config, not by editing core/ or config/.
 *
 * Enable by setting SLACK_WEBHOOK_URL in the environment file, then calling
 * `new SlackNotifierPlugin().postRunSummary(summary)` from global-teardown.
 */
class SlackNotifierPlugin {
  constructor(webhookUrl = process.env.SLACK_WEBHOOK_URL) {
    this.webhookUrl = webhookUrl;
  }

  async postRunSummary({ total, passed, failed, skipped, durationMs, environment }) {
    if (!this.webhookUrl) {
      log.warn('SLACK_WEBHOOK_URL not configured - skipping Slack notification.');
      return;
    }

    const text =
      `*Test Run Summary (${environment})*\n` +
      `Total: ${total} | Passed: ${passed} | Failed: ${failed} | Skipped: ${skipped}\n` +
      `Duration: ${(durationMs / 1000).toFixed(1)}s`;

    await axios.post(this.webhookUrl, { text });
    log.info('Posted run summary to Slack.');
  }
}

module.exports = SlackNotifierPlugin;
