const config = require('../config/ConfigManager');
const { Logger } = require('../logger/Logger');

const log = new Logger('DatabaseClient');

/**
 * DatabaseClient
 * ----------------------------------------------------------------------------
 * Thin façade over a DB driver so tests call `db.query(...)` / `db.execute(...)`
 * without caring which engine backs the environment (SQL Server, Oracle,
 * PostgreSQL, MySQL). This class defines the CONTRACT; wire in a real driver
 * for your project by installing ONE of the following and implementing
 * `_connect()`/`_query()` below - keeping the framework's own dependency
 * footprint minimal until a project actually needs DB validation:
 *
 *   PostgreSQL : npm install pg            (config.database.type = 'postgres')
 *   MySQL      : npm install mysql2         (config.database.type = 'mysql')
 *   SQL Server : npm install mssql          (config.database.type = 'mssql')
 *   Oracle     : npm install oracledb       (config.database.type = 'oracle')
 *
 * IMPORTANT: DatabaseClient.assertNotProd() must be called before any
 * insert/update/delete/stored-procedure call, to enforce the "PROD is
 * read-only" rule from the spec.
 */
class DatabaseClient {
  constructor() {
    this.type = config.get('database.type');
    this._pool = null;
  }

  async connect() {
    if (this._pool) return this._pool;

    switch (this.type) {
      case 'postgres': {
        let Pool;
        try {
          ({ Pool } = require('pg')); // eslint-disable-line global-require
        } catch {
          throw new Error('DatabaseClient(postgres) requires "pg". Install with: npm install pg');
        }
        this._pool = new Pool({
          host: config.get('database.host'),
          port: config.get('database.port'),
          database: config.get('database.name'),
          user: config.get('database.user'),
          password: config.get('database.password'),
        });
        break;
      }
      case 'mysql': {
        let mysql;
        try {
          mysql = require('mysql2/promise'); // eslint-disable-line global-require
        } catch {
          throw new Error('DatabaseClient(mysql) requires "mysql2". Install with: npm install mysql2');
        }
        this._pool = await mysql.createPool({
          host: config.get('database.host'),
          port: config.get('database.port'),
          database: config.get('database.name'),
          user: config.get('database.user'),
          password: config.get('database.password'),
        });
        break;
      }
      default:
        throw new Error(
          `DatabaseClient does not have a built-in adapter for "${this.type}" yet. ` +
            `Add a case in DatabaseClient.connect() following the postgres/mysql pattern above.`
        );
    }

    log.info(`Connected to ${this.type} database "${config.get('database.name')}"`);
    return this._pool;
  }

  /** Read-only SELECT - safe to run in any environment, including PROD. */
  async query(sql, params = []) {
    const pool = await this.connect();
    log.debug(`QUERY: ${sql}`, { params });
    if (this.type === 'postgres') {
      const result = await pool.query(sql, params);
      return result.rows;
    }
    if (this.type === 'mysql') {
      const [rows] = await pool.execute(sql, params);
      return rows;
    }
    throw new Error(`query() not implemented for "${this.type}".`);
  }

  /** Mutating statement (INSERT/UPDATE/DELETE) - blocked against PROD by design. */
  async execute(sql, params = []) {
    config.assertNotProd(`DatabaseClient.execute("${sql.slice(0, 40)}...")`);
    return this.query(sql, params);
  }

  async close() {
    if (this._pool && this._pool.end) {
      await this._pool.end();
      this._pool = null;
    }
  }
}

module.exports = DatabaseClient;
