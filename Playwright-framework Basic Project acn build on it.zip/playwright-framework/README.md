# FinTech Playwright Automation Framework

Enterprise-grade, JavaScript-only Playwright automation framework designed as the
standard automation platform for Banking/FinTech projects.

> **Scope note:** This is a genuinely working core framework (POM, base classes,
> config/env management, API layer, reporting, data factories, CI). Heavier
> capabilities from the original spec — multi-vendor DB drivers, AI-generated
> tests from Figma/Jira/Swagger, MCP integrations, security/accessibility
> scanning, dashboards — are documented as **extension points** with a clear
> contract (see `docs/EXTENSION_POINTS.md`) rather than faked. Wire in the real
> service/library your project needs behind those contracts; the architecture
> doesn't change.

## Quick Start

```bash
npm install
npx playwright install --with-deps
npm test                     # runs all tests against ENV=dev (default)
npm run test:qa              # runs against QA environment
npm run test:smoke           # only @smoke tagged tests
npm run test:headed          # see the browser
npm run test:report          # open the last Playwright HTML report
npm run allure:generate && npm run allure:open   # Allure report
```

Sample tests run against public demo targets out of the box (no company
credentials needed to prove the framework works):

- UI: https://www.saucedemo.com
- API: https://reqres.in

Point `BASE_URL` / `API_BASE_URL` in `environments/.env.<env>` at your real
application to use this framework for real.

## Folder Guide

| Folder                             | Responsibility                                                                                |
| ---------------------------------- | --------------------------------------------------------------------------------------------- |
| `config/`                          | Singleton `ConfigManager` — resolves env vars per environment.                                |
| `core/`                            | `BasePage`, `BaseComponent`, and the `actions/assertions/waits/elements` every page inherits. |
| `pages/`                           | Page Objects (`pages/banking/`) and reusable Components (`pages/components/`).                |
| `api/`                             | `BaseAPI` + per-resource Service classes (Repository pattern) + JSON schemas.                 |
| `tests/`                           | Spec files: `tests/ui`, `tests/api`, tag freely with `@smoke @regression @api` etc.           |
| `fixtures/`                        | Custom Playwright `test`/`expect` with page objects & services pre-wired.                     |
| `data/`                            | `data/json` static fixtures, `data/factories` Faker-based Factory/Builder classes.            |
| `environments/`                    | One `.env.<name>` per environment: dev/qa/sit/uat/preprod/prod.                               |
| `database/`                        | `DatabaseClient` façade — contract for SQL Server/Oracle/Postgres/MySQL.                      |
| `logger/`                          | Structured console + file logger.                                                             |
| `global-setup/` `global-teardown/` | Run once before/after the whole suite.                                                        |
| `plugins/`                         | Opt-in integrations (Slack/Teams/Jira/...) that don't touch core files.                       |
| `constants/`                       | Shared tag/role/status string constants.                                                      |
| `scripts/`                         | Maintenance scripts (`clean.js`).                                                             |
| `docs/`                            | Architecture, extension points, contribution guide.                                           |

## How to Add a New Page (minimal code)

1. Create `pages/<domain>/YourPage.js` extending `BasePage`.
2. Declare locators as getters using `this.el.byTestId/byRole/smart(...)`.
3. Implement `isLoaded()`.
4. Register it as a fixture in `fixtures/pageFixtures.js` (one line) so every
   test can request it, e.g. `yourPage: async ({ page }, use) => use(new YourPage(page))`.

No other file needs to change. See `docs/HOW_TO_ADD_A_PAGE.md` for a full example.

## How to Add a New Environment (config-only)

1. Copy `environments/.env.dev` to `environments/.env.<name>`.
2. Update `BASE_URL`, `API_BASE_URL`, credentials, DB settings.
3. Run with `cross-env ENV=<name> playwright test` (or add an npm script).

No framework code changes required — see `docs/HOW_TO_ADD_AN_ENVIRONMENT.md`.

## Design Principles Applied

- **Page Object Model + Component Object Pattern** — `core/BasePage.js`, `core/BaseComponent.js`
- **Factory & Builder** — `data/factories/UserFactory.js` (`UserFactory`, `UserBuilder`)
- **Singleton** — `config/ConfigManager.js`
- **Service/Repository (API)** — `api/BaseAPI.js` + `api/services/*`
- **Smart/self-healing locators** — `core/elements/BaseElements.js` (`.smart()` chains `.or()` fallbacks)
- **SOLID/DRY/KISS** — every cross-cutting concern (waits, actions, assertions, logging) lives in exactly one class that all Page Objects inherit; adding behavior never means duplicating it.

## Documentation

- `docs/ARCHITECTURE.md` — architecture, dependency, and flow diagrams.
- `docs/EXTENSION_POINTS.md` — what's fully implemented vs. what's a documented contract to wire up (DB drivers, AI/MCP hooks, security/a11y/visual testing, dashboard).
- `docs/HOW_TO_ADD_A_PAGE.md`
- `docs/HOW_TO_ADD_A_TEST.md`
- `docs/HOW_TO_ADD_API_TESTS.md`
- `docs/HOW_TO_ADD_AN_ENVIRONMENT.md`
- `docs/HOW_TO_ADD_TEST_DATA.md`
- `docs/BEST_PRACTICES.md`
- `docs/NAMING_CONVENTIONS.md`
- `docs/CONTRIBUTING.md`

## CI/CD

`.github/workflows/playwright.yml` is ready to run on push/PR, and via manual
dispatch against a chosen environment. Uploads Playwright HTML + Allure
reports as build artifacts. Adapt the same steps (`npm ci` → `npx playwright
install --with-deps` → `npx playwright test` → generate/upload reports) for
Azure DevOps, GitLab CI, or Jenkins — see `docs/ARCHITECTURE.md` for a Docker
notes section.
