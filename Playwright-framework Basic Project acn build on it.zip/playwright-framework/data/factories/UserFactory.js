const { faker } = require('@faker-js/faker');

/**
 * UserFactory
 * ----------------------------------------------------------------------------
 * Factory Pattern for generating disposable, realistic test data. Combine
 * with UserBuilder below for fine-grained control (Builder Pattern) when a
 * test needs specific overrides while keeping everything else random/valid.
 */
class UserFactory {
  static create(overrides = {}) {
    const firstName = faker.person.firstName();
    const lastName = faker.person.lastName();
    return {
      firstName,
      lastName,
      email: faker.internet.email({ firstName, lastName }).toLowerCase(),
      password: faker.internet.password({ length: 12, memorable: false }),
      phone: faker.phone.number(),
      dateOfBirth: faker.date.birthdate({ min: 18, max: 75, mode: 'age' }).toISOString().split('T')[0],
      address: {
        street: faker.location.streetAddress(),
        city: faker.location.city(),
        state: faker.location.state(),
        zipCode: faker.location.zipCode(),
        country: faker.location.country(),
      },
      ...overrides,
    };
  }

  static createMany(count = 5, overrides = {}) {
    return Array.from({ length: count }, () => UserFactory.create(overrides));
  }

  /** Generates a banking-flavored account payload - useful for FinTech domain tests. */
  static createAccount(overrides = {}) {
    return {
      accountNumber: faker.finance.accountNumber(10),
      routingNumber: faker.finance.routingNumber(),
      iban: faker.finance.iban(),
      accountType: faker.helpers.arrayElement(['CHECKING', 'SAVINGS', 'CREDIT']),
      balance: Number(faker.finance.amount({ min: 0, max: 100000, dec: 2 })),
      currency: faker.finance.currencyCode(),
      ...overrides,
    };
  }
}

/**
 * UserBuilder - Builder Pattern
 * Use when a test needs to construct a user step by step with specific,
 * readable overrides, e.g.:
 *   const user = new UserBuilder().withEmail('qa@bank.com').withRole('admin').build();
 */
class UserBuilder {
  constructor() {
    this._user = UserFactory.create();
  }

  withEmail(email) {
    this._user.email = email;
    return this;
  }

  withPassword(password) {
    this._user.password = password;
    return this;
  }

  withRole(role) {
    this._user.role = role;
    return this;
  }

  withName(firstName, lastName) {
    this._user.firstName = firstName;
    this._user.lastName = lastName;
    return this;
  }

  build() {
    return { ...this._user };
  }
}

module.exports = { UserFactory, UserBuilder };
